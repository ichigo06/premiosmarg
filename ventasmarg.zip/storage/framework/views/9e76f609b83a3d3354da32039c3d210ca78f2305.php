<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="content" class="page-content">
    <div className="page-content-wrap">
        <div className="text-center">
            <h2>Agregar ventas MARG</h2>
        </div>
        <form>
            <div>
                <input type="text" placeholder="Agregar Nombre"> 
            </div>
            <div>
                <input type="text" placeholder="Agregar Apellido"> 
            </div>
            <div>
                <input type="text" placeholder="Agregar Correo Electrónico"> 
            </div>
            <div>
                <input type="text" placeholder="Agregar Whatsapp"> 
            </div>
            <div>
                <input type="text" placeholder="Agregar Télefono"> 
            </div>
        </form>
    </div>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ventasmarg\resources\views/user.blade.php ENDPATH**/ ?>