<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="content" class="page-content">
    <div className="page-content-wrap">
        <div className="text-center">
            <h2>Agregar Usuarios MARG</h2>
        </div>
        <?php if(Route::has('login')): ?>
            <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/dashboard')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Dashboard</a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Log in</a>

                    <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>" class="ml-4 text-sm text-gray-700 dark:text-gray-500 underline">Register</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(url('/users')); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div>
                <input type="text" name="nombres" placeholder="Agregar Nombre" value=""> 
            </div>
            <div>
                <input type="text" name="apellidos" placeholder="Agregar Apellidos" value=""> 
            </div>
            <div>
                <input type="text" name="nombres" placeholder="Usuario" value=""> 
            </div>
            <div>
                <input type="text" name="nombres" placeholder="Contraseña" value=""> 
            </div>
            <div>
                <input type="text" name="correo" placeholder="Agregar Correo Electrónico" value=""> 
            </div>
            <div>
                <input type="text" name ="whatsapp" placeholder="Agregar Whatsapp" value=""> 
            </div>
            <div>
                <input type="text" name="telefono" placeholder="Agregar Télefono" value=""> 
            </div>
            <div>
                <input type="submit" value="Agregar">
            </div>
        </form>
    </div>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ventasmarg\resources\views/users/create.blade.php ENDPATH**/ ?>