<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(auth()->check() && auth()->user()->hasRole('Administrador')): ?>
<div id="content" class="page-content">
    <div class="page-content-wrap text-center">
        <div class="text-center">
            <h2>Editar Role</h2>
        </div>
            <div class="pb-2">
                El usuario es : <?php echo e($user->name); ?>

            </div>
            <?php echo Form::model($user ,['route' => ['admin.users.update', $user], 'method' => 'put']); ?>

            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PATCH')); ?>

                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="">
                    <label for="">
                        <input id="typeclient5"  name="model_id" value="" type="hidden">
                        <?php echo Form::checkbox('roles', $role->id , null , ['class' => 'mr-1 select-type5']); ?>

                        <?php echo $role->name; ?>

                    </label>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo Form::submit('Asignar Rol', ['class' => 'button-send-role mt-2 mr-1']); ?> 
            <?php echo Form::close(); ?>

    </div>
</div>
<?php endif; ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ventasmarg\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>