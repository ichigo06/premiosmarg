<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('authentication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(auth()->check() && auth()->user()->hasRole('Administrador')): ?>
<div id="content" class="page-content">
    <div class="page-content-wrap">
        <div class="text-center pb-1">
            <h2 class="fw-bold">Agregar Usuarios MARG</h2>
        </div>
        <form class="form-control-marg" action="<?php echo e(url('/admin')); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="pb-3">
                <?php if($errors->has('id_consumers')): ?>
                    <span class="error text-danger"><?php echo e($errors->first('id_consumers')); ?></span>
                <?php endif; ?> 
                <input id="typeclient"  name="id_consumers" value="" type="hidden">
                <select  class="form-marg-client form-control select-type">
                    <option value="0">Seleccionar cliente MARG</option>
                <?php $__currentLoopData = $consumers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consumer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($consumer->id); ?>"><?php echo e($consumer->cliente); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <?php if($errors->has('name')): ?>
                    <span class="error text-danger"><?php echo e($errors->first('name')); ?></span>
                <?php endif; ?>
                <input type="text" name="name" placeholder="Agregar nombres y apellidos" id="dates" value=""> 
            </div>
            <div>
                <?php if($errors->has('dni')): ?>
                    <span class="error text-danger"><?php echo e($errors->first('dni')); ?></span>
                <?php endif; ?>
                <input type="text" name="dni" placeholder="DNI"  id="dni" value=""> 
            </div>
            <div>
                <input class="button" id="sendText"  type="button" value="Generar contraseña">
            </div>
            <div>
                <?php if($errors->has('password')): ?>
                    <span class="error text-danger"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?> 
                <input type="password" name="password" placeholder="Introducir Contraseña" id="password" value=""> 
            </div>
            <div>
                <?php if($errors->has('email')): ?>
                    <span class="error text-danger"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?> 
                <input type="text" name="email" placeholder="Agregar Correo Electrónico" id="email" value=""> 
            </div>
            <div>
                <?php if($errors->has('whatsapp')): ?>
                    <span class="error text-danger"><?php echo e($errors->first('whatsapp')); ?></span>
                <?php endif; ?> 
                <input type="text" name="whatsapp" placeholder="Agregar Whatsapp" id="wsp" value=""> 
            </div>
            <div>
                <?php if($errors->has('tel')): ?>
                    <span class="error text-danger"><?php echo e($errors->first('tel')); ?></span>
                <?php endif; ?> 
                <input type="text" name="tel" placeholder="Agregar Télefono" id="tel" value=""> 
            </div>
            <div>
                <input class="button" type="submit" value="Agregar">
            </div>
        </form>
        <form action="  " method="post">
            <div class="pb-3">
                <input id="typeclient5"  name="role_id" value="1" type="hidden">
                <select name="" id="" class="select-type5">
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <input class="button" type="submit" value="Agregar">
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ventasmarg\resources\views/admin/create.blade.php ENDPATH**/ ?>