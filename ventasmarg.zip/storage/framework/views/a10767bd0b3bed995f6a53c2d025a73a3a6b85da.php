<div>
    <div class="pb-3">
        <div wire:ignore>
            <input   wire:ignore id="typeclient2"  name="id_consumers_sales" value="1" type="hidden">
            <select wire:model="selectedCustomers" class="select2 form-control select-type2"  id="selectedCustomers">
                <option value="0">Seleccionar cliente MARG</option>
            <?php $__currentLoopData = $consumers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consumer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($consumer->id); ?>"><?php echo e($consumer->cliente); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
            </select>
        </div>
    </div>
    <form class="form-control-marg" action="<?php echo e(url('/sales')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

        <?php if(!is_null($users)): ?>
        <div class="pb-3"> 
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($errors->has('id_consumers_sales')): ?>
                        <span class="error text-danger"><?php echo e($errors->first('id_consumers_sales')); ?></span>
                    <?php endif; ?>
                    <div>
                        <input   type="hidden" name="id_consumers_sales[]" value="<?php echo e($user->id_consumers); ?>"><?php echo e($user->consumers->cliente); ?>

                    </div>
                    <div>
                        <input type="hidden" value="<?php echo e($user->id); ?>" name="id_users_sales[]"><?php echo e($user->name); ?>

                    </div>
                    <div>
                        <?php if($errors->has('venta')): ?>
                            <span class="error text-danger"><?php echo e($errors->first('venta')); ?></span>
                        <?php endif; ?>  
                        <input type="text" name="venta[]" placeholder="Venta del usuario" value=""> 
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <div>
                <input  class="button" type="submit" value="Agregar">
            </div>
        </form>
        <script>
            document.addEventListener('livewire:load', function(){
                $('.select2').select2();
                $('.select2').on('change' , function(){
                    window.livewire.find('<?php echo e($_instance->id); ?>').set('selectedCustomers' , this.value);
                })
            })
        </script>
        <style>
            .select2 {
                background: #2A81B4;
                padding: 20px;
                width: 100%;
                justify-content: center;
            }
        </style>
</div>
        
<?php /**PATH C:\laragon\www\ventasmarg\resources\views/livewire/consumer-user.blade.php ENDPATH**/ ?>