<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('authentication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(auth()->check() && auth()->user()->hasRole('Administrador')): ?>
<div id="content" class="page-content">
    <div class="page-content-wrap">
        <div class="text-center fw-bold">
            <h2>Agregar Ventas Marg</h2>
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('objective-user')->html();
} elseif ($_instance->childHasBeenRendered('83CCApY')) {
    $componentId = $_instance->getRenderedChildComponentId('83CCApY');
    $componentTag = $_instance->getRenderedChildComponentTagName('83CCApY');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('83CCApY');
} else {
    $response = \Livewire\Livewire::mount('objective-user');
    $html = $response->html();
    $_instance->logRenderedChild('83CCApY', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php endif; ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ventasmarg\resources\views/objective/create.blade.php ENDPATH**/ ?>