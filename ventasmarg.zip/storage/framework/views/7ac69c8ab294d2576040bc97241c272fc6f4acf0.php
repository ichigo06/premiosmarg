<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(auth()->check() && auth()->user()->hasRole('Administrador')): ?>
<div id="content" class="page-content">
    <div className="page-content-wrap">
        <div className="text-center">
            <h2>Editar usuario</h2>
        </div>
            <div>
                El usuario es : 
            </div>
            <?php echo Form::model($user ,['route' => ['admin.update', $user], 'method' => 'put']); ?>

            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PATCH')); ?>

                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <label for="">
                        <input id="typeclient5"  name="model_id" value="" type="hidden">
                        <?php echo Form::checkbox('roles', $role->id , null , ['class' => 'mr-1 select-type5']); ?>

                        <?php echo $role->name; ?>

                    </label>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo Form::submit('Asignar Rol', ['class' => 'mr-1']); ?> 
            <?php echo Form::close(); ?>

    </div>
</div>
<?php endif; ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ventasmarg\resources\views/admin/edit.blade.php ENDPATH**/ ?>