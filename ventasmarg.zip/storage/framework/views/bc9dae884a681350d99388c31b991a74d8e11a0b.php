<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('authentication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(auth()->check() && auth()->user()->hasRole('Administrador')): ?>
<div id="content" class="page-content">
    <div class="page-content-wrap">
        <div class="table-content">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Vendedor</th>
                        <th>Objetivo del mes</th>
                        <th>Fecha del objetivo</th>
                        <th>Editar</th>
                        <th>Eliminar</th>
                    </tr>
                </thead>
                
                <thead>
                    <?php $__currentLoopData = $objectives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $objective): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($objective->users->name); ?></td>
                        <td><?php echo e($objective->objective); ?></td> 
                        <td><?php echo e($objective->created_at); ?></td>
                        <td>
                            <a class="button-td" href="<?php echo e(url('/objective/'.$objective->id.'/edit')); ?>">
                                Editar
                            </a>
                        </td>
                        <td>
                            <form action="<?php echo e(url('/objective/'.$objective->id)); ?>" method="post">
                                <?php echo e(csrf_field( )); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <button class="button-td" type="submit" onclick="return confirm('¿ Borrar ?');">Borrar</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </thead>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ventasmarg\resources\views/objective/index.blade.php ENDPATH**/ ?>