<div id="content" class="page-content">
    <div class="page-content-wrap">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center pb-4">
                    <h2>Objetivos por mes</h2>
                    <input type="month">
                </div>
                <div class="col-6">
                    <canvas id="myChart" width="400" height="400"></canvas>
                </div>
                <div class="col-6">
                    <div class="date_information">
                        Mi cliente: <span><?php echo e(Auth::user()->consumers->cliente); ?></span>
                    </div>
                    <div class="date_information">
                        Ruc de la empresa: <span> <?php echo e(Auth::user()->consumers->ruc); ?></span>
                    </div>
                    <div class="date_information">
                        Mi identificación: <span> <?php echo e(Auth::user()->dni); ?></span>
                    </div>
                    <div class="date_information">
                        Mis ingresos: <span> S/. <?php echo e($monto); ?></span>
                    </div>
                    <div class="date_information">
                        Objetivo del mes: <span>S./ <?php echo e(Auth::user()->objective); ?></span> 
                    </div>
                    <div class="date_information">
                        Premio Marg: <span> Canasta Marg</span> 
                    <div class="date_information">
                        Tu avance del mes:
                    </div>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" style="width: <?php echo e($monto*100/Auth::user()->objective); ?>%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">S/. <?php echo e($monto); ?></div>
                    </div>
                    <div class="date_information">
                        Tu objetivo del mes:
                    </div>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" style="width: 100%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">S./ <?php echo e(Auth::user()->objective); ?></div>
                    </div>
                    <div class="mt-4 text-center">
                        <a href="" class="btn btn-primary">ir a tu siguiente objetivo</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\ventasmarg\resources\views/livewire/index.blade.php ENDPATH**/ ?>