<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="content" class="page-content">
    <div className="page-content-wrap">
        <div className="text-center">
            <h2>Editar usuario</h2>
        </div>
        <form action="<?php echo e(url('/users/'.$clients->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PATCH')); ?>

            <div>
                <input type="text" name="nombres" placeholder="Agregar Nombre" value="<?php echo e($clients->nombres); ?>"> 
            </div>
            <div>
                <input type="text" name="apellidos" placeholder="Agregar Apellido" value="<?php echo e($clients->apellidos); ?>"> 
            </div>
            <div>
                <input type="text" name="correo" placeholder="Agregar Correo Electrónico" value="<?php echo e($clients->correo); ?>"> 
            </div>
            <div>
                <input type="text" name ="whatsapp" placeholder="Agregar Whatsapp" value="<?php echo e($clients->whatsapp); ?>"> 
            </div>
            <div>
                <input type="text" name="telefono" placeholder="Agregar Télefono" value="<?php echo e($clients->telefono); ?>"> 
            </div>
            <div>
                <input type="submit" value="Editar">
            </div>
        </form>
    </div>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ventasmarg\resources\views/users/edit.blade.php ENDPATH**/ ?>