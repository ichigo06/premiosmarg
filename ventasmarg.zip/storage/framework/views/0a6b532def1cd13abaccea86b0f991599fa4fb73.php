<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('authentication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(Auth::check()): ?>
<?php if(auth()->check() && auth()->user()->hasRole('Administrador')): ?>
<div id="content" class="page-content">
    <div class="page-content-wrap">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <h2>Hola bienvenido <?php echo e(Auth::user()->name); ?></h2>
                </div>
                <div class="col-12 text-center">
                    <div>
                        <img src="<?php echo e(asset('img/administradormarg.jpg')); ?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php endif; ?>
<?php if(auth()->check() && auth()->user()->hasRole('Vendedor')): ?>
<?php if(Auth::check()): ?>
<div id="content" class="page-content">
    <div class="page-content-wrap">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center pb-2">
                    <h2>Hola bienvenido(@) <?php echo e(Auth::user()->name); ?></h2>
                </div>
                <div class="col-12 text-center">
                    <div class="seller_dashboard">
                        <img src="<?php echo e(asset('img/vendedormarg.png')); ?>" alt="">
                    </div>
                    <div class="seller_button">
                        <a href="<?php echo e(url('seller')); ?>">Ir a mis objetivos</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>
<?php endif; ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laragon\www\ventasmarg\resources\views/dashboard.blade.php ENDPATH**/ ?>