<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="content" class="page-content">
    <div className="page-content-wrap">
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nombres</th>
                    <th>Apellidos</th>
                    <th>Correo Electrónico</th>
                    <th>Whatsapp</th>
                    <th>Teléfono</th>
                    <th>Accion Editar</th>
                    <th>Accion Borrar</th>
                </tr>
            </thead>
            
            <thead>
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($client->nombres); ?></td>
                    <td><?php echo e($client->apellidos); ?></td>
                    <td><?php echo e($client->correo); ?></td>
                    <td><?php echo e($client->whatsapp); ?></td>
                    <td><?php echo e($client->telefono); ?></td>
                    <td>
                        <a href="<?php echo e(url('/users/'.$client->id.'/edit')); ?>">
                            Editar
                        </a>
                    </td>
                    <td>
                        <form action="<?php echo e(url('/users/'.$client->id)); ?>" method="post">
                            <?php echo e(csrf_field( )); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <button type="submit" onclick="return confirm('¿ Borrar ?');">Borrar</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </thead>
        </table>
    </div>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ventasmarg\resources\views/users/index.blade.php ENDPATH**/ ?>