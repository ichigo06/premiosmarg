<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('authentication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(auth()->check() && auth()->user()->hasRole('Administrador')): ?>
<div id="content" class="page-content">
    <div class="page-content-wrap">
        <div class="text-center pb-1">
            <h2 class="fw-bold">Editar Cliente</h2>
        </div>
        <form class="form-control-marg" action="<?php echo e(url('/sales/'.$sales->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PATCH')); ?>

            <div>
                <input type="text" name="venta" placeholder="Ventas" value="<?php echo e($sales->venta); ?>"> 
            </div>
            <div>
                <input type="text" name="created_at" placeholder="Fecha" value="<?php echo e($sales->created_at); ?>"> 
            </div>
            <div>
                <input type="submit" value="Editar la venta">
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ventasmarg\resources\views/sales/edit.blade.php ENDPATH**/ ?>