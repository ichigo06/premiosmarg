<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('authentication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(auth()->check() && auth()->user()->hasRole('Administrador')): ?>
<div id="content" class="page-content">
    <div class="page-content-wrap">
        <div class="text-center fw-bold">
            <h2>Agregar Ventas Marg</h2>
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('consumer-user')->html();
} elseif ($_instance->childHasBeenRendered('87whO7y')) {
    $componentId = $_instance->getRenderedChildComponentId('87whO7y');
    $componentTag = $_instance->getRenderedChildComponentTagName('87whO7y');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('87whO7y');
} else {
    $response = \Livewire\Livewire::mount('consumer-user');
    $html = $response->html();
    $_instance->logRenderedChild('87whO7y', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>
<?php endif; ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ventasmarg\resources\views/sales/create.blade.php ENDPATH**/ ?>