<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="content" class="page-content"></div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php /**PATH C:\laragon\www\ventasmarg\resources\views/ventasmarg.blade.php ENDPATH**/ ?>