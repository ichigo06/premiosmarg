<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('authentication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(auth()->check() && auth()->user()->hasRole('Administrador')): ?>
<div id="content" class="page-content">
    <div class="page-content-wrap">
        <div class="table-content">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Cliente</th>
                        <th>Ruc</th>
                        <th>Distrito</th>
                        <th>Region</th>
                        <th>Zona</th>
                        <th>Accion Editar</th>
                        <th>Accion Borrar</th>  
                    </tr>
                </thead>
                
                <thead>
                    <?php $__currentLoopData = $consumers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consumer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($consumer->cliente); ?></td>
                        <td><?php echo e($consumer->ruc); ?></td>
                        <td><?php echo e($consumer->distrito); ?></td>
                        <td><?php echo e($consumer->region); ?></td>
                        <td><?php echo e($consumer->zona); ?></td>
                        <td>
                            <a class="button-td" href="<?php echo e(url('/consumers/'.$consumer->id.'/edit')); ?>">
                                Editar
                            </a>
                        </td>
                        <td>
                            <form action="<?php echo e(url('/consumers/'.$consumer->id)); ?>" method="post">
                                <?php echo e(csrf_field( )); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <button class="button-td" type="submit" onclick="return confirm('¿ Borrar ?');">Borrar</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </thead>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ventasmarg\resources\views/consumers/index.blade.php ENDPATH**/ ?>