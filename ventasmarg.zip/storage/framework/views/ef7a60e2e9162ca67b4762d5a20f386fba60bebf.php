<?php if(Auth::check()): ?>
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('authentication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('filter-date')->html();
} elseif ($_instance->childHasBeenRendered('OBATaYj')) {
    $componentId = $_instance->getRenderedChildComponentId('OBATaYj');
    $componentTag = $_instance->getRenderedChildComponentTagName('OBATaYj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OBATaYj');
} else {
    $response = \Livewire\Livewire::mount('filter-date');
    $html = $response->html();
    $_instance->logRenderedChild('OBATaYj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('first-component')->html();
} elseif ($_instance->childHasBeenRendered('x4p6eU9')) {
    $componentId = $_instance->getRenderedChildComponentId('x4p6eU9');
    $componentTag = $_instance->getRenderedChildComponentTagName('x4p6eU9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('x4p6eU9');
} else {
    $response = \Livewire\Livewire::mount('first-component');
    $html = $response->html();
    $_instance->logRenderedChild('x4p6eU9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\ventasmarg\resources\views/seller/index.blade.php ENDPATH**/ ?>