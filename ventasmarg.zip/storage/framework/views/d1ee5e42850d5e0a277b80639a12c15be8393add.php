<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('authentication', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(auth()->check() && auth()->user()->hasRole('Administrador')): ?>
<div id="content" class="page-content">
    <div class="page-content-wrap">
        <div class="table-content">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Cliente</th>
                        <th>Nombres y apellidos</th>
                        <th>Correo Electrónico</th>
                        <th>DNI</th>
                        <th>Whatsapp</th>
                        <th>Teléfono</th>
                        <th>Accion Editar</th>
                        <th>Accion Borrar</th>
                    </tr>
                </thead>
                
                <thead>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($user->consumers->cliente); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->dni); ?></td>
                        <td><?php echo e($user->whatsapp); ?></td>
                        <td><?php echo e($user->tel); ?></td>
                        <!-- <td><?php echo e($user->whatsapp); ?></td>
                        <td><?php echo e($user->telefono); ?></td> -->
                        <td>
                            <a class="button-td" href="<?php echo e(url('/admin/'.$user->id.'/edit')); ?>">
                                Editar
                            </a>
                        </td>
                        <td>
                            <form action="<?php echo e(url('/admin/'.$user->id)); ?>" method="post">
                                <?php echo e(csrf_field( )); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <button class="button-td" type="submit" onclick="return confirm('¿ Borrar ?');">Borrar</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </thead>
            </table>
        </div>
    </div>
</div>
<?php endif; ?>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ventasmarg\resources\views/admin/index.blade.php ENDPATH**/ ?>