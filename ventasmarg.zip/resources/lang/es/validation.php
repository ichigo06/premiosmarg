<?php 

return [
    'required' => 'El campo :attribute es obligatorio'
];