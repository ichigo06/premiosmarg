<?php return array (
  'consumer-user' => 'App\\Http\\Livewire\\ConsumerUser',
  'filter-date' => 'App\\Http\\Livewire\\FilterDate',
  'first-component' => 'App\\Http\\Livewire\\FirstComponent',
  'objective-user' => 'App\\Http\\Livewire\\ObjectiveUser',
);